Vishnu & Ajisha wedding website
Open index.html locally to preview.
Upload all files/folders to a GitHub repository, then import that repository into Vercel.
The countdown targets 25 October 2026 at 11:00 AM IST.
